/// <reference path="./typings/browser.d.ts" />

declare var require: any;
declare var module: { id: string };